import random
import string
import tkinter as tk
from tkinter import messagebox, font

class PasswordGenerator:
    def __init__(self, root):
        self.root = root
        self.root.title("Password Generator")
        self.root.geometry("400x300")
        self.root.config(bg="#eaeaea")

        self.title_font = font.Font(family="Helvetica", size=16, weight="bold")
        self.label_font = font.Font(family="Helvetica", size=12)
        
        tk.Label(self.root, text="Password Generator", font=self.title_font, bg="#eaeaea", fg="#333").pack(pady=10)

        tk.Label(self.root, text="Length:", bg="#eaeaea", font=self.label_font).pack(pady=5)
        self.len_entry = tk.Entry(self.root, width=10, font=self.label_font, borderwidth=2, relief="groove")
        self.len_entry.pack(pady=5)

        tk.Label(self.root, text="Special chars (Y/N):", bg="#eaeaea", font=self.label_font).pack(pady=5)
        self.sp_entry = tk.Entry(self.root, width=10, font=self.label_font, borderwidth=2, relief="groove")
        self.sp_entry.pack(pady=5)

        tk.Button(self.root, text="Generate", command=self.gen_pwd, bg="#4CAF50", fg="white", font=self.label_font).pack(pady=20)

        self.res_label = tk.Label(self.root, text="", bg="#eaeaea", font=("Helvetica", 14, "bold"), fg="#4CAF50")
        self.res_label.pack(pady=10)

    def gen_pwd(self):
        try:
            l = int(self.len_entry.get())
            sp = self.sp_entry.get().strip().upper()

            if l < 1:
                raise ValueError("Length must be > 0.")

            chars = string.ascii_letters + string.digits
            if sp == 'Y':
                chars += string.punctuation

            pwd = ''.join(random.choice(chars) for _ in range(l))
            self.res_label.config(text=f"Password: {pwd}")
        except ValueError as e:
            messagebox.showerror("Input Error", str(e))

if __name__ == "__main__":
    root = tk.Tk()
    app = PasswordGenerator(root)
    root.mainloop()

