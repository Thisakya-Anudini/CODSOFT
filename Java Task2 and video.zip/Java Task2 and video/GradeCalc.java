import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GradeCalc extends JFrame implements ActionListener {
    private JTextField[] tfScores;
    private JLabel lblTotal, lblAvg, lblGrade, lblStatus;
    private JButton btnCalc;
    private int numSubjects;

    public GradeCalc(int numSubjects) {
        this.numSubjects = numSubjects;

        setTitle("Grade Calculator");
        setSize(900, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(15, 15));

        // Header Panel
        JPanel pnlHeader = new JPanel();
        pnlHeader.setBackground(Color.BLACK); 
        JLabel lblHeader = new JLabel("Grade Calculator");
        lblHeader.setFont(new Font("Arial", Font.BOLD, 24));
        lblHeader.setForeground(Color.WHITE); 
        pnlHeader.add(lblHeader);
        add(pnlHeader, BorderLayout.NORTH);

        // Center Panel
        JPanel pnlCenter = new JPanel();
        pnlCenter.setLayout(new GridLayout(numSubjects + 1, 2, 5, 10)); 
        pnlCenter.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        pnlCenter.setBackground(new Color(240, 240, 240)); 

        JLabel lblInstr = new JLabel("Enter marks for each subject (0-100)");
        lblInstr.setFont(new Font("Arial", Font.PLAIN, 16));
        pnlCenter.add(lblInstr);
        pnlCenter.add(new JLabel()); 

        tfScores = new JTextField[numSubjects];
        for (int i = 0; i < numSubjects; i++) {
            JLabel lblSub = new JLabel("Subject " + (i + 1) + ":");
            lblSub.setFont(new Font("Arial", Font.PLAIN, 14));
            pnlCenter.add(lblSub);

            tfScores[i] = new JTextField();
            tfScores[i].setFont(new Font("Arial", Font.PLAIN, 14)); 
            tfScores[i].setPreferredSize(new Dimension(60, 25));
            pnlCenter.add(tfScores[i]);
        }

        add(pnlCenter, BorderLayout.CENTER);

        // Right Panel (Results)
        JPanel pnlRight = new JPanel();
        pnlRight.setLayout(new GridBagLayout());
        pnlRight.setBackground(new Color(200, 240, 255)); 
        pnlRight.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        pnlRight.setPreferredSize(new Dimension(250, 150)); 

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        lblTotal = createResultLbl("Total Marks:");
        lblAvg = createResultLbl("Average Marks:");
        lblGrade = createResultLbl("Grade:");
        lblStatus = createResultLbl("");

        gbc.gridx = 0;
        gbc.gridy = 0;
        pnlRight.add(lblTotal, gbc);

        gbc.gridy = 1;
        pnlRight.add(lblAvg, gbc);

        gbc.gridy = 2;
        pnlRight.add(lblGrade, gbc);

        gbc.gridy = 3;
        pnlRight.add(lblStatus, gbc);

        add(pnlRight, BorderLayout.EAST);

        // Button Panel
        JPanel pnlButton = new JPanel();
        pnlButton.setBackground(new Color(240, 240, 240)); 

        btnCalc = new JButton("Calculate");
        btnCalc.setFont(new Font("Arial", Font.BOLD, 16));
        btnCalc.setBackground(new Color(0, 123, 255)); 
        btnCalc.setForeground(Color.WHITE);
        btnCalc.setFocusPainted(false);
        btnCalc.setPreferredSize(new Dimension(120, 40));
        btnCalc.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnCalc.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btnCalc.addActionListener(this);

        pnlButton.add(btnCalc);
        add(pnlButton, BorderLayout.SOUTH);

        setVisible(true);
    }

    private JLabel createResultLbl(String text) {
        JLabel lbl = new JLabel(text + " ");
        lbl.setFont(new Font("Arial", Font.PLAIN, 16));
        lbl.setForeground(new Color(50, 50, 50)); 
        return lbl;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("Calculate")) {
            try {
                double total = 0;
                for (JTextField tf : tfScores) {
                    double score = Double.parseDouble(tf.getText());
                    if (score < 0 || score > 100) {
                        lblStatus.setText("Marks must be between 0 and 100.");
                        return;
                    }
                    total += score;
                }

                double avg = total / numSubjects;
                String grade = getGrade(avg);

                lblTotal.setText("Total Marks      : " + String.format("%.2f", total));
                lblAvg.setText("Average Marks : " + String.format("%.2f", avg));
                lblGrade.setText("Grade              : " + grade);
                lblStatus.setText("Calculation completed.");
            } catch (NumberFormatException ex) {
                lblStatus.setText("Invalid input. Please enter numerical values.");
            }
        }
    }

    private String getGrade(double avg) {
        if (avg >= 75) return "A";
        else if (avg >= 65) return "B";
        else if (avg >= 55) return "C";
        else if (avg >= 35) return "D";
        else return "F";
    }

    public static void main(String[] args) {
        int subjects = 5; 
        new GradeCalc(subjects);
    }
}
