import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class NumberGuessingGame {
    private static final int MIN = 1;
    private static final int MAX = 100;
    private static final int MAX_TRIES = 7;

    private JFrame frame;
    private JTextField inputField;
    private JLabel feedback;
    private JLabel tries;
    private JButton submitBtn;
    private JButton replayBtn;
    
    private int targetNum;
    private int numTries;
    private boolean isCorrect;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new NumberGuessingGame().createAndShowGUI());
    }

    public void createAndShowGUI() {
        frame = new JFrame("Number Guessing Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 500);
        frame.setLayout(new BorderLayout());

        JPanel topPanel = new JPanel();
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        topPanel.setBackground(new Color(135, 206, 250));
        JLabel instruction = new JLabel("Guess the number between " + MIN + " and " + MAX + ":");
        instruction.setFont(new Font("Arial", Font.BOLD, 16));
        instruction.setForeground(Color.BLACK);
        topPanel.add(instruction);
        frame.add(topPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        feedback = new JLabel(" ");
        feedback.setFont(new Font("Arial", Font.PLAIN, 14));
        feedback.setForeground(Color.RED);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        centerPanel.add(feedback, gbc);

        JLabel prompt = new JLabel("Enter your guess:");
        prompt.setFont(new Font("Arial", Font.PLAIN, 14));
        prompt.setForeground(Color.BLACK);
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        centerPanel.add(prompt, gbc);

        inputField = new JTextField(10);
        gbc.gridx = 1;
        centerPanel.add(inputField, gbc);

        submitBtn = new JButton("Submit");
        submitBtn.setBackground(new Color(0, 128, 0));
        submitBtn.setForeground(Color.WHITE);
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        centerPanel.add(submitBtn, gbc);

        tries = new JLabel("Tries: 0");
        tries.setFont(new Font("Arial", Font.PLAIN, 14));
        tries.setForeground(Color.BLACK);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        centerPanel.add(tries, gbc);

        frame.add(centerPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        bottomPanel.setBackground(new Color(255, 250, 205));

        replayBtn = new JButton("Play Again");
        replayBtn.setBackground(new Color(139, 69, 19));
        replayBtn.setForeground(Color.GRAY);
        bottomPanel.add(replayBtn);
        frame.add(bottomPanel, BorderLayout.SOUTH);

        submitBtn.addActionListener(new SubmitListener());
        replayBtn.addActionListener(new ReplayListener());

        startNewGame();

        frame.setVisible(true);
    }

    private void startNewGame() {
        Random rand = new Random();
        targetNum = rand.nextInt(MAX - MIN + 1) + MIN;
        numTries = 0;
        isCorrect = false;
        feedback.setText("Guess a number between " + MIN + " and " + MAX + ".");
        inputField.setText("");
        submitBtn.setEnabled(true);
        replayBtn.setEnabled(false);
    }

    private class SubmitListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (isCorrect) {
                return;
            }

            try {
                int guess = Integer.parseInt(inputField.getText());

                if (guess < MIN || guess > MAX) {
                    feedback.setText("Your guess is out of bounds. Please try again.");
                } else {
                    numTries++;
                    tries.setText("Tries: " + numTries);
                    if (guess < targetNum) {
                        feedback.setText("Too low! Try again.");
                    } else if (guess > targetNum) {
                        feedback.setText("Too high! Try again.");
                    } else {
                        isCorrect = true;
                        feedback.setText("Congratulations! You guessed the number. It took you " + numTries + " tries.");
                        submitBtn.setEnabled(false);
                        replayBtn.setEnabled(true);
                    }

                    if (numTries >= MAX_TRIES && !isCorrect) {
                        feedback.setText("Sorry, you've used all your tries. The number was " + targetNum + ".");
                        submitBtn.setEnabled(false);
                        replayBtn.setEnabled(true);
                    }
                }
            } catch (NumberFormatException ex) {
                feedback.setText("Invalid input. Please enter a number.");
            }
        }
    }

    private class ReplayListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            startNewGame();
        }
    }
}
