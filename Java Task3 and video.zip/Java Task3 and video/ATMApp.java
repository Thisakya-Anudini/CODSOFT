import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

//bank account class
class BankAccount {
    private double balance;

    public BankAccount(double initialBalance) {
        this.balance = initialBalance;
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amt) {
        if (amt > 0) {
            balance += amt;
        }
    }

    public boolean withdraw(double amt) {
        if (amt > 0 && amt <= balance) {
            balance -= amt;
            return true;
        }
        return false;
    }
}

// ATM functionality class
class ATM {
    private BankAccount acc;

    public ATM(BankAccount acc) {
        this.acc = acc;
    }

    public boolean withdraw(double amt) {
        return acc.withdraw(amt);
    }

    public void deposit(double amt) {
        acc.deposit(amt);
    }

    public double checkBalance() {
        return acc.getBalance();
    }
}

//ATM GUI class
class ATMGUI extends JFrame implements ActionListener {
    private ATM atm;
    private JTextField amtField;
    private JLabel statusLbl, detail1Lbl, detail2Lbl;

    public ATMGUI(ATM atm) {
        this.atm = atm;

        setTitle("ATM");
        setSize(500, 350);
        setLayout(new BorderLayout(10, 10));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

     
        JPanel hdrPanel = new JPanel();
        hdrPanel.setBackground(new Color(0, 10, 10));
        JLabel hdrLbl = new JLabel("Welcome to the ATM!");
        hdrLbl.setFont(new Font("Arial", Font.BOLD, 20));
        hdrLbl.setForeground(Color.WHITE);
        hdrPanel.add(hdrLbl);
        add(hdrPanel, BorderLayout.NORTH);

        JPanel ctrPanel = new JPanel();
        ctrPanel.setLayout(new BorderLayout(10, 10));
        ctrPanel.setBackground(Color.WHITE);

 
        JPanel inptPanel = new JPanel();
        inptPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        inptPanel.setBackground(Color.WHITE);

        JLabel amtLbl = new JLabel("Amount ($):");
        amtLbl.setFont(new Font("Arial", Font.PLAIN, 16));
        inptPanel.add(amtLbl);

        amtField = new JTextField(15);
        amtField.setFont(new Font("Arial", Font.PLAIN, 16));
        inptPanel.add(amtField);

        ctrPanel.add(inptPanel, BorderLayout.NORTH);

       
        JPanel btnPanel = new JPanel();
        btnPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        btnPanel.setBackground(Color.WHITE);

        JButton depBtn = createBtn("Deposit");
        JButton withBtn = createBtn("Withdraw");
        JButton balBtn = createBtn("Check Balance");

        btnPanel.add(depBtn);
        btnPanel.add(withBtn);
        btnPanel.add(balBtn);

        ctrPanel.add(btnPanel, BorderLayout.CENTER);

 
        JPanel dtlsPanel = new JPanel();
        dtlsPanel.setLayout(new GridLayout(2, 1, 10, 10));
        dtlsPanel.setBackground(Color.WHITE);

        detail1Lbl = new JLabel(" ");
        detail1Lbl.setFont(new Font("Arial", Font.PLAIN, 16));
        dtlsPanel.add(detail1Lbl);

        detail2Lbl = new JLabel(" ");
        detail2Lbl.setFont(new Font("Arial", Font.PLAIN, 16));
        dtlsPanel.add(detail2Lbl);

        ctrPanel.add(dtlsPanel, BorderLayout.SOUTH);

        add(ctrPanel, BorderLayout.CENTER);

       
        JPanel ftrPanel = new JPanel();
        ftrPanel.setBackground(new Color(0, 123, 255));
        statusLbl = new JLabel("Please Select an Action.");
        statusLbl.setFont(new Font("Arial", Font.PLAIN, 16));
        statusLbl.setForeground(Color.WHITE);
        ftrPanel.add(statusLbl);
        add(ftrPanel, BorderLayout.SOUTH);

    
        depBtn.addActionListener(this);
        withBtn.addActionListener(this);
        balBtn.addActionListener(this);

        setVisible(true);
    }

   
    private JButton createBtn(String txt) {
        JButton btn = new JButton(txt);
        btn.setFont(new Font("Arial", Font.BOLD, 14));
        btn.setBackground(new Color(0, 153, 76));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

       
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(new Color(0, 130, 65));
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(new Color(0, 153, 76));
            }
        });

        return btn;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();

        
        detail1Lbl.setText("");
        detail2Lbl.setText("");

        try {
            double amt = 0;
            if (cmd.equals("Deposit") || cmd.equals("Withdraw")) {
                amt = Double.parseDouble(amtField.getText());
                if (amt <= 0) {
                    statusLbl.setText("Please Enter a Positive Amount.");
                    return;
                }
            }

            switch (cmd) {
                case "Deposit":
                    atm.deposit(amt);
                    statusLbl.setText("Deposit Successful");
                    detail1Lbl.setText("Deposited Amount   :    $" + amt);
                    detail2Lbl.setText("New Balance           :    $" + atm.checkBalance());
                    break;

                case "Withdraw":
                    if (atm.withdraw(amt)) {
                        statusLbl.setText("Withdrawal Successful");
                        detail1Lbl.setText("Withdrawal Amount    :    $" + amt);
                        detail2Lbl.setText("New Balance             :    $" + atm.checkBalance());
                    } else {
                        statusLbl.setText("Insufficient Funds.");
                        detail1Lbl.setText("");
                        detail2Lbl.setText("");
                    }
                    break;

                case "Check Balance":
                    statusLbl.setText("Balance Checked");
                    detail1Lbl.setText("Current Balance:  $" + atm.checkBalance());
                    detail2Lbl.setText("");
                    break;

                default:
                    statusLbl.setText("Unknown command.");
                    break;
            }

        } catch (NumberFormatException ex) {
            if (!cmd.equals("Check Balance")) {
                statusLbl.setText("Please Enter a Valid Amount.");
            }
        }

      
        amtField.setText("");
    }
}

// Main application class
public class ATMApp {
    public static void main(String[] args) {
        BankAccount acc = new BankAccount(10000.00); 
        ATM atm = new ATM(acc);
        new ATMGUI(atm);
    }
}
