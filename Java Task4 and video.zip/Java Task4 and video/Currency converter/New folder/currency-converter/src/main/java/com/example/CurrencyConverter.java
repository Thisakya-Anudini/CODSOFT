package com.example;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class CurrencyConverter extends JFrame implements ActionListener {
    private JComboBox<String> baseCurBox;
    private JComboBox<String> targetCurBox;
    private JTextField amtField;
    private JLabel resLabel;
    private JButton convButton;

    private static final String API_URL = "https://api.exchangerate-api.com/v4/latest/";

    public CurrencyConverter() {
        setTitle("Currency Converter");
        setSize(400, 300);
        setLayout(new GridLayout(5, 2, 10, 10));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      
        baseCurBox = new JComboBox<>(new String[]{"USD", "EUR", "GBP", "JPY", "AUD"});
        targetCurBox = new JComboBox<>(new String[]{"USD", "EUR", "GBP", "JPY", "AUD"});
        amtField = new JTextField();
        convButton = new JButton("Convert");
        resLabel = new JLabel("Result: ");

       
        add(new JLabel("Base Currency:"));
        add(baseCurBox);
        add(new JLabel("Target Currency:"));
        add(targetCurBox);
        add(new JLabel("Amount:"));
        add(amtField);
        add(convButton);
        add(resLabel);

        
        convButton.addActionListener(this);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String baseCur = (String) baseCurBox.getSelectedItem();
        String targetCur = (String) targetCurBox.getSelectedItem();
        double amt;

        try {
            amt = Double.parseDouble(amtField.getText());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid amount");
            return;
        }

        double rate = fetchRate(baseCur, targetCur);

        if (rate == -1) {
            resLabel.setText("Error fetching rate.");
        } else {
            double convertedAmt = amt * rate;
            resLabel.setText(String.format("Result: %.2f %s", convertedAmt, targetCur));
        }
    }

    public double fetchRate(String baseCur, String targetCur) {
        try {
            String urlStr = API_URL + baseCur;
            @SuppressWarnings("deprecation")
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

           
            ObjectMapper mapper = new ObjectMapper();
            JsonNode json = mapper.readTree(response.toString());
            JsonNode rates = json.get("rates");
            return rates.get(targetCur).asDouble();

        } catch (Exception ex) {
            ex.printStackTrace();
            return -1;
        }
    }

    public static void main(String[] args) {
        new CurrencyConverter();
    }
}