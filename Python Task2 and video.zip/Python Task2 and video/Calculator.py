import tkinter as tk
from tkinter import messagebox

class Calculator:
    def __init__(self, root):
        self.root = root
        self.root.title("Calculator")
        self.root.geometry("300x400")
        self.root.config(bg="#282c34")

        self.res_var = tk.StringVar()

        self.ent = tk.Entry(self.root, textvariable=self.res_var, font=("Helvetica", 16), bd=10, insertwidth=2, width=14, borderwidth=4, bg="#ffffff", fg="#000000")
        self.ent.grid(row=0, column=0, columnspan=4, padx=10, pady=10)

        btns = [
            ('7', 1, 0), ('8', 1, 1), ('9', 1, 2), ('/', 1, 3),
            ('4', 2, 0), ('5', 2, 1), ('6', 2, 2), ('*', 2, 3),
            ('1', 3, 0), ('2', 3, 1), ('3', 3, 2), ('-', 3, 3),
            ('0', 4, 0), ('C', 4, 1), ('=', 4, 2), ('+', 4, 3),
        ]

        for (text, r, c) in btns:
            if text == '=':
                btn = tk.Button(self.root, text=text, padx=20, pady=20, command=self.calc, bg="#4CAF50", fg="white", font=("Helvetica", 12, "bold"))
            elif text == 'C':
                btn = tk.Button(self.root, text=text, padx=20, pady=20, command=self.clear, bg="#F44336", fg="white", font=("Helvetica", 12, "bold"))
            else:
                btn = tk.Button(self.root, text=text, padx=20, pady=20, command=lambda t=text: self.append(t), bg="#2196F3", fg="white", font=("Helvetica", 12))
            btn.grid(row=r, column=c, padx=5, pady=5)

    def append(self, value):
        curr_text = self.res_var.get()
        new_text = curr_text + value
        self.res_var.set(new_text)

    def clear(self):
        self.res_var.set("")

    def calc(self):
        try:
            result = eval(self.res_var.get())
            self.res_var.set(result)
        except Exception:
            messagebox.showerror("Error", "Invalid input")
            self.clear()

if __name__ == "__main__":
    root = tk.Tk()
    app = Calculator(root)
    root.mainloop()
