import tkinter as tk
from tkinter import messagebox
from tkinter import font

class ToDoList_App:
    def __init__(self, root):
        self.root = root
        self.root.title("Professional To-Do List Application")
        self.root.geometry("450x450")
        self.root.config(bg="#f2f2f2")
        
        self.title_font = font.Font(family="Helvetica", size=18, weight="bold")
        self.button_font = font.Font(family="Helvetica", size=10, weight="bold")
        self.task_font = font.Font(family="Helvetica", size=12)

        self.tasks = []

        title_label = tk.Label(self.root, text="My To-Do List", font=self.title_font, bg="#f2f2f2", fg="#333333")
        title_label.pack(pady=10)

        input_frame = tk.Frame(self.root, bg="#f2f2f2")
        input_frame.pack(pady=10)

        self.task_entry = tk.Entry(input_frame, width=28, font=self.task_font, borderwidth=2, relief="groove")
        self.task_entry.grid(row=0, column=0, padx=10)

        self.add_button = tk.Button(input_frame, text="Add Task", command=self.add_task, bg="#4CAF50", fg="white", font=self.button_font)
        self.add_button.grid(row=0, column=1)

        listbox_frame = tk.Frame(self.root, bg="#f2f2f2")
        listbox_frame.pack(pady=10)

        self.task_scrollbar = tk.Scrollbar(listbox_frame, orient=tk.VERTICAL)
        self.task_listbox = tk.Listbox(listbox_frame, height=10, width=35, font=self.task_font, yscrollcommand=self.task_scrollbar.set, selectbackground="#90EE90", activestyle="none")
        self.task_listbox.grid(row=0, column=0)
        self.task_scrollbar.config(command=self.task_listbox.yview)
        self.task_scrollbar.grid(row=0, column=1, sticky="ns")

        button_frame = tk.Frame(self.root, bg="#f2f2f2")
        button_frame.pack(pady=10)

        self.complete_button = tk.Button(button_frame, text="Mark as Completed", command=self.mark_completed, bg="#2196F3", fg="white", font=self.button_font)
        self.complete_button.grid(row=0, column=0, padx=10)

        self.delete_button = tk.Button(button_frame, text="Delete Task", command=self.delete_task, bg="#F44336", fg="white", font=self.button_font)
        self.delete_button.grid(row=0, column=1, padx=10)

    def add_task(self):
        task = self.task_entry.get()
        if task:
            self.tasks.append({"task": task, "completed": False})
            self.task_listbox.insert(tk.END, task)
            self.task_entry.delete(0, tk.END)
        else:
            messagebox.showwarning("Input Error", "Please enter a task.")

    def mark_completed(self):
        try:
            selected_index = self.task_listbox.curselection()[0]
            self.tasks[selected_index]["completed"] = True
            task = self.tasks[selected_index]["task"]
            self.task_listbox.delete(selected_index)
            self.task_listbox.insert(selected_index, f"{task} (Completed)")
        except IndexError:
            messagebox.showwarning("Selection Error", "Please select a task.")

    def delete_task(self):
        try:
            selected_index = self.task_listbox.curselection()[0]
            self.tasks.pop(selected_index)
            self.task_listbox.delete(selected_index)
        except IndexError:
            messagebox.showwarning("Selection Error", "Please select a task.")

if __name__ == "__main__":
    root = tk.Tk()
    app = ToDoList_App(root)
    root.mainloop()
