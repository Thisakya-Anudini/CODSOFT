import tkinter as tk
from tkinter import messagebox
import random
from PIL import Image, ImageTk

def determine_winner(user_choice, computer_choice):
    if user_choice == computer_choice:
        return "It's a tie!"
    elif (user_choice == "Rock" and computer_choice == "Scissors") or \
         (user_choice == "Scissors" and computer_choice == "Paper") or \
         (user_choice == "Paper" and computer_choice == "Rock"):
        return "You win!"
    else:
        return "You lose!"

def play_game(user_choice):
    computer_choice = random.choice(["Rock", "Paper", "Scissors"])
    result = determine_winner(user_choice, computer_choice)

    user_choice_label.config(image=choice_images[user_choice])
    computer_choice_label.config(image=choice_images[computer_choice])


    user_choice_text.config(text="Your Choice")
    computer_choice_text.config(text="Computer's Choice")

    result_label.config(text=result)

def play_again():
    user_choice_label.config(image='')
    computer_choice_label.config(image='')
    user_choice_text.config(text="")
    computer_choice_text.config(text="")
    result_label.config(text="")

root = tk.Tk()
root.title("Rock-Paper-Scissors Game")
root.geometry("800x750")  

upper_panel = tk.Frame(root)
upper_panel.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

background_image = Image.open(r"C:\Users\Asus\Desktop\4thsem\CODSOFT_Python_Programming\Python Task4 and video\image.jpg")
background_image = background_image.resize((800, 300), Image.LANCZOS)  
bg_photo = ImageTk.PhotoImage(background_image)

bg_label = tk.Label(upper_panel, image=bg_photo)
bg_label.pack(fill=tk.BOTH, expand=True)

lower_panel = tk.Frame(root, bg="lightgray")
lower_panel.pack(side=tk.BOTTOM, fill=tk.BOTH, expand=True)

rock_image = Image.open(r"C:\Users\Asus\Desktop\4thsem\CODSOFT_Python_Programming\Python Task4 and video\rock.jpg").resize((100, 100), Image.LANCZOS)
paper_image = Image.open(r"C:\Users\Asus\Desktop\4thsem\CODSOFT_Python_Programming\Python Task4 and video\paper.jpg").resize((100, 100), Image.LANCZOS)
scissors_image = Image.open(r"C:\Users\Asus\Desktop\4thsem\CODSOFT_Python_Programming\Python Task4 and video\scissors.jpg").resize((100, 100), Image.LANCZOS)

rock_photo = ImageTk.PhotoImage(rock_image)
paper_photo = ImageTk.PhotoImage(paper_image)
scissors_photo = ImageTk.PhotoImage(scissors_image)

choice_images = {
    "Rock": rock_photo,
    "Paper": paper_photo,
    "Scissors": scissors_photo
}

buttons_frame = tk.Frame(lower_panel, bg="lightgray")
buttons_frame.pack(pady=10)

instruction_label = tk.Label(buttons_frame, text="Select Your Move", font=("Helvetica", 16, "bold"), bg="lightgray")
instruction_label.grid(row=0, column=0, columnspan=3, pady=10)

rock_button = tk.Button(buttons_frame, image=rock_photo, command=lambda: play_game("Rock"), bg="white")
rock_button.grid(row=1, column=0, padx=10)

paper_button = tk.Button(buttons_frame, image=paper_photo, command=lambda: play_game("Paper"), bg="white")
paper_button.grid(row=1, column=1, padx=10)

scissors_button = tk.Button(buttons_frame, image=scissors_photo, command=lambda: play_game("Scissors"), bg="white")
scissors_button.grid(row=1, column=2, padx=10)

results_frame = tk.Frame(lower_panel, bg="lightgray")
results_frame.pack(pady=10)

user_choice_text = tk.Label(results_frame, text="", font=("Helvetica", 12), bg="lightgray")
user_choice_text.grid(row=0, column=0, padx=20)

computer_choice_text = tk.Label(results_frame, text="", font=("Helvetica", 12), bg="lightgray")
computer_choice_text.grid(row=0, column=2, padx=20)

user_choice_label = tk.Label(results_frame, image='', bg="lightgray")
user_choice_label.grid(row=1, column=0, padx=20)

computer_choice_label = tk.Label(results_frame, image='', bg="lightgray")
computer_choice_label.grid(row=1, column=2, padx=20)

result_label = tk.Label(lower_panel, text="", font=("Helvetica", 14, "bold"), bg="lightgray")
result_label.pack(pady=10)

play_again_button = tk.Button(lower_panel, text="Play Again", command=play_again, bg="white")
play_again_button.pack(pady=20)

root.mainloop()

