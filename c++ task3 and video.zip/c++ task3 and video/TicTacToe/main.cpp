#include <iostream>
#include <vector>
using namespace std;

void showBoard(const vector<char>& b) {

    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            cout << b[i * 3 + j] << " ";
        }
        cout << "\n";
    }
}

bool hasWon(const vector<char>& b, char p) {
    for (int i = 0; i < 3; ++i) {
        if ((b[i * 3] == p && b[i * 3 + 1] == p && b[i * 3 + 2] == p) ||
            (b[i] == p && b[i + 3] == p && b[i + 6] == p)) {
            return true;
        }
    }
    return (b[0] == p && b[4] == p && b[8] == p) ||
           (b[2] == p && b[4] == p && b[6] == p);
}

bool isDraw(const vector<char>& b) {
    for (char cell : b) {
        if (cell == ' ') return false;
    }
    return true;
}

int main() {
       cout << "Welcome to The Tic-Tac-Toe Game!";
    char playAgain;

    do {
        vector<char> b(9, ' ');
        char currPlayer = 'X';
        int move;

        while (true) {
            showBoard(b);
            cout << "Player " << currPlayer << ", enter your move (1-9): ";
            cin >> move;

            if (move < 1 || move > 9 || b[move - 1] != ' ') {
                cout << "Invalid move. Try again.";
                continue;
            }

            b[move - 1] = currPlayer;

            if (hasWon(b, currPlayer)) {
                showBoard(b);
                cout << "Player " << currPlayer << " wins!";
                break;
            }

            if (isDraw(b)) {
                showBoard(b);
                cout << "It's a draw!";
                break;
            }

            currPlayer = (currPlayer == 'X') ? 'O' : 'X';
        }

        cout << "     Do you want to play again? (Y/N): ";
        cin >> playAgain;

    } while (playAgain == 'Y' || playAgain == 'y');

    return 0;
}

