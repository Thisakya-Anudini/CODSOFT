#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct T {
    string desc;
    bool done;
};

vector<T> lst;

void addT() {
    string d;
    cout << "Enter task description: ";
    cin.ignore(); // clear input buffer
    getline(cin, d);
    lst.push_back({d, false});
    cout << "Task added!" << endl;
}

void viewT() {
    if (lst.empty()) {
        cout << "No tasks available!" << endl;
        return;
    }
    cout << "\nTo-Do List:" << endl;
    for (size_t i = 0; i < lst.size(); i++) {
        cout << i + 1 << ". " << lst[i].desc << " [" << (lst[i].done ? "Completed" : "Pending") << "]" << endl;
    }
}

void markT() {
    int n;
    cout << "Enter task number to mark as completed: ";
    cin >> n;
    if (n > 0 && n <= lst.size()) {
        lst[n - 1].done = true;
        cout << "Task marked!" << endl;
    } else {
        cout << "Invalid task number!" << endl;
    }
}

void removeT() {
    int n;
    cout << "Enter task number to remove: ";
    cin >> n;
    if (n > 0 && n <= lst.size()) {
        lst.erase(lst.begin() + n - 1);
        cout << "Task removed!" << endl;
    } else {
        cout << "Invalid task number!" << endl;
    }
}

int main() {
    int ch;

    do {
        cout << "\nTo-Do List Manager" << endl;
        cout << "1. Add Task" << endl;
        cout << "2. View Tasks" << endl;
        cout << "3. Mark Task as Completed" << endl;
        cout << "4. Remove Task" << endl;
        cout << "5. Exit" << endl;
        cout << "Choose an option: ";
        cin >> ch;

        switch (ch) {
            case 1:
                addT();
                break;
            case 2:
                viewT();
                break;
            case 3:
                markT();
                break;
            case 4:
                removeT();
                break;
            case 5:
                cout << "Exiting..." << endl;
                break;
            default:
                cout << "Invalid option!" << endl;
        }
    } while (ch != 5);

    return 0;
}
