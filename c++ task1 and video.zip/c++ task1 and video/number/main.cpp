#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main() {
    srand(static_cast<unsigned int>(time(0)));
    char playAgain;

    do {
        int num = rand() % 100 + 1;
        int guess = 0;
        const int maxAttempts = 10;

        cout << "Welcome to the Number Guessing Game!" << endl;
        cout << "I've selected a number between 1 and 100." << endl;
        cout << "You have a maximum of " << maxAttempts << " attempts to guess the number." << endl;

        for (int attempts = maxAttempts; attempts > 0; --attempts) {
            cout << "Attempts left: " << attempts << endl;
            cout << "\nEnter your guess: ";
            cin >> guess;

            if (guess < num) {
                cout << "Too low! Try again." << endl;
            } else if (guess > num) {
                cout << "Too high! Try again." << endl;
            } else {
                cout << "Congratulations! You've guessed the correct number: " << num << endl;
                break;
            }
        }

        if (guess != num) {
            cout << "Sorry! You've used all your attempts. The correct number was: " << num << endl;
        }

        cout << "\nDo you want to play again? (Y/N): ";
        cin >> playAgain;

    } while (playAgain == 'Y' || playAgain == 'y');

    return 0;
}

